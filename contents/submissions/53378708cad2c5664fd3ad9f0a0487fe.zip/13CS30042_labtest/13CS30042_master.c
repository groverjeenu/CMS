//Jeenu Grover
//13CS30042
//M/C No. : 46

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <signal.h>

#define MAXN 1000
#define MAXM 1000

int pipe_in[MAXN][MAXN][2];

int pipe_out[MAXN][MAXN][2];

int edge[MAXN][MAXN];




int main()
{

	int n,m,i,j,k,x,y;

	scanf("%d %d",&n,&m);

	for(i = 0 ;i < n; i++)
	{
		for(j = 0;j< n;j++)
			edge[i][j] = 0;
	}

	for(i = 0;i<m;i++)
	{
		scanf("%d %d",&x,&y);
		x--;
		y--;

		edge[x][y] = 1;
		edgbe[y][x] = 1;

	}

	for( i = 0;i<n;i++)
	{
		for( j = 0;j<n;j++)
		{
			//if(edge[x][y] == 1)
			pipe(pipe_in[x][y]);
		}
	}

	int pid_n;

	for( i= 0;i<n;i++)
	{
		pid_n = fork();
		if(pid_n == 0)
		{
			for(j = 0;i<n;j++)
			{
					if(edge[x][y])
					{
						dup2(STDIN_FILENO,pipe_in[x][y][0]);
						dup2(STDOUT_FILENO,pipe_in[y][x][1]);
						close(pipe_in[x][y][1]);
						close(pipe_in[y][x][0]);

						execlp("./node","./node",n,m);
					}
			}
			 
		}

	}


	for( i = 0;i<n;i++)
	{
		for( j = 0;j<n;j++)
		{
			//if(edge[x][y] == 1)
			close(pipe_in[x][y][0]);
			close(pipe_in[x][y][1]);
		}
	}



	return 0;
}