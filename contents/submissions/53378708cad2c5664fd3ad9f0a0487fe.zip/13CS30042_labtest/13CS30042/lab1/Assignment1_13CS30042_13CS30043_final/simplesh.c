// Assignment 1
// Q2. Basic Shell

// Objective
// The shell is a program that interprets commands and acts as an intermediary between the user and the inner workings of the
// operating system and as such is arguably one of the most important parts of a Unix system.
// In this assignment, we shall start making our very own version of a Unix shell.

// Group Details
// Member 1: Jeenu Grover (13CS30042)
// Member 2: Ashish Sharma (13CS30043)

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/types.h>
#include <pwd.h>
#include <grp.h>
#include <time.h>
#include <langinfo.h>

char* escape(char* buffer)
{
    int i,j;
    int l = strlen(buffer) + 1;
    char* dest  =  (char*)malloc(1024*sizeof(char));
    char* ptr=dest;
    for(i=0; i<l; i++)
    {
        if( buffer[i]=='\\' )
        {
            continue;
        }
        *ptr++ = buffer[i];
    }
    *ptr = '\0';
    return dest;
}

// Function to parse the entered command
char ** lexer(char * buffer,int * cnt)
{
    int i = 1,count  = 0,start = 0,f = 0;
    char ** a = (char**)malloc(1024*sizeof(char*));
    if(buffer[0] != ' ')
        start = 0;
    while(1)
    {
        if(buffer[i-1] == '\\' && buffer[i] == ' ')
        {
            f = 1;
            i = i+2;
            continue;
        }
        if((buffer[i] == ' ' || buffer[i] == '\n') && buffer[i-1] != ' ')
        {
            a[count++] = (char*)malloc(256*sizeof(char));
            strncpy(a[count-1],buffer + start,i - start);
            if(f == 1)
            {
                strcpy(a[count-1],escape(a[count-1]));
                f = 0;
            }
        }
        else if(buffer[i] != ' ' && buffer[i-1] == ' ')
        {
            start = i;

        }
        if(buffer[i] == '\n')
            break;
        i++;
    }
    a[count] = NULL;
    *cnt  = count;
    return a;
}

// Function for executing clear command
void clear()
{
    printf("\033[H\033[J");
}

// Function for executing cd(change directory) command
void changeDir(const char *path)
{
    struct stat st = {0};
    if (stat(path, &st) == -1)
    {
        printf("%s: No such file or directory\n",path);
    }
    else
    {
        chdir(path);
    }
}

// Function for executing pwd command
void pwd()
{
    char cwd[1024];
    getcwd(cwd, sizeof(cwd));
    printf("%s\n", cwd);

}

// Function for executing mkdir(make directory) command
void makeDir(const char *path)
{
    struct stat st = {0};

    if (stat(path, &st) == -1)
    {
        mkdir(path, 0700);
    }
    else
    {
        printf("cannot create directory %s: File exists\n",path);
    }

}

// Function for executing ls command
void ls(const char *currDir)
{
    DIR *directory;
    struct dirent *dirPtr;
    int i;

    if(currDir == NULL)
    {
        printf("Error: Could not get the working directory\n");
        return;
    }

    directory = opendir((const char*)currDir);
    if(directory == NULL)
    {
        printf("Error: Could not open the working directory\n");
    }

    for(i = 0; (dirPtr = readdir(directory))!=NULL; i++)
    {
        printf("%s\n",dirPtr->d_name);
    }
    printf("\n");
}

// Function for executing ls -l command
void lsl(const char *currDir)
{
    DIR *directory;
    struct dirent *dirPtr;
    struct stat fileStat;
    char *path;
    struct passwd *pwd;
    struct group *grp;
    struct tm *tm;
    char datestring[1024];
    int i;

    path = (char *)malloc(1024*sizeof(char));

    if(currDir == NULL)
    {
        printf("Error: Could not get the working directory\n");
        return;
    }

    directory = opendir((const char*)currDir);
    if(directory == NULL)
    {
        printf("Error: Could not open the working directory\n");
    }

    for(i = 0; (dirPtr = readdir(directory))!=NULL; i++)
    {
        sprintf(path, "%s/%s", currDir, dirPtr->d_name);
        stat(path, &fileStat);  // Get the fileStat

        // Print the Permissions
        printf( (S_ISDIR(fileStat.st_mode)) ? "d" : "-");
        printf( (fileStat.st_mode & S_IRUSR) ? "r" : "-");
        printf( (fileStat.st_mode & S_IWUSR) ? "w" : "-");
        printf( (fileStat.st_mode & S_IXUSR) ? "x" : "-");
        printf( (fileStat.st_mode & S_IRGRP) ? "r" : "-");
        printf( (fileStat.st_mode & S_IWGRP) ? "w" : "-");
        printf( (fileStat.st_mode & S_IXGRP) ? "x" : "-");
        printf( (fileStat.st_mode & S_IROTH) ? "r" : "-");
        printf( (fileStat.st_mode & S_IWOTH) ? "w" : "-");
        printf( (fileStat.st_mode & S_IXOTH) ? "x" : "-");

        printf("\t%zu\t",fileStat.st_nlink);    // Print Number of links

        // Print user name
        if ((pwd = getpwuid(fileStat.st_uid)) != NULL) printf("%s\t", pwd->pw_name);
        else printf("%d\t", fileStat.st_uid);

        // Print out group name
        if ((grp = getgrgid(fileStat.st_gid)) != NULL)
            printf("%s\t", grp->gr_name);
        else
            printf("%d\t", fileStat.st_gid);

        printf("%jd\t",fileStat.st_size);   // Print size of the file
        tm = localtime(&fileStat.st_mtime); // Print Last modified Datetime

        strftime(datestring, sizeof(datestring), nl_langinfo(D_T_FMT), tm);

        printf("%s\t", datestring);
        printf("%s\n",dirPtr->d_name);  // Print Filename
    }
    printf("\n");
}


// Function for executing rmdir(remove directory) command
void removeDir(const char *path)
{
    if(rmdir(path))
    {
        printf("Directory could not be deleted\n");
    }
}

// Function for executing history command
void history()
{
    char temp[1024];
    FILE *fp;
    char *buffer;
    size_t size = 1024;

    strcpy(temp,getenv("HOME"));
    strcat(temp,"/history.txt");

    fp = fopen(temp,"r");

    buffer = (char *)malloc(1024*sizeof(char));

    if (fp == NULL)
        printf("File not found\n");
    int ctr = 1;

    while (getline(&buffer, &size, fp) != -1)
    {
        printf("\t%d\t%s",ctr++, buffer);
    }
    fclose(fp);
}

// Function for executing history <Argument> command
void historyArg(int n)
{
    FILE *fp;
    char **buffer;
    int i;
    size_t size = 1024;
    buffer = (char **)malloc(10000*sizeof(char *));
    for(i=0; i<10000; ++i)
    {
        buffer[i] = (char *)malloc(size*sizeof(char));
    }
    char temp[400];
    strcpy(temp,getenv("HOME"));
    strcat(temp,"/history.txt");
    fp = fopen(temp, "r");
    if (fp == NULL)
        printf("File not found\n");
    int ctr = 1;

    while (getline(&(buffer[ctr]), &size, fp) != -1)
    {
        ctr++;
    }
    if(ctr-n<=0)
    {
        i = 1;
    }
    else i = ctr-n;
    for(; i<ctr; ++i)
    {
        printf("\t%d\t%s",i, buffer[i]);
    }

    fclose(fp);
}


int main(int argc, char *argv[], char *envp[])
{
    int cnt,i,j,k,envIdx;
    char homeDir[1024],temp[1024],currDir[1024];
    FILE *fp = NULL;

    strcpy(homeDir,getenv("HOME"));
    strcpy(temp,homeDir);
    strcat(temp,"/history.txt");    // Path for history file

    size_t size = 1024;
    char * buffer = (char * )malloc(size*sizeof(char));
    char **cmd ;

    changeDir(homeDir); // Set current working directory as home directory

    while(1){
        getcwd(currDir, sizeof(currDir));   // Get Current Working Directory
        printf("%s >",currDir);

        getline(&buffer,&size,stdin);   // Get Command from the user
        fp =fopen(temp,"a");            // Open the history file
        if(strcmp(buffer,"\n") == 0)
        {
            continue;                   // Ignore Execution of '\n' command
        }

        cmd = lexer(buffer,&cnt);       // Parse the command entered

        if(cnt > 0) fprintf(fp,"%s",buffer);    // Print the command in history file
        fclose(fp);                     // Close the history file


        // Handling 'clear' command
        if(strcmp(cmd[0],"clear") == 0)
        {
            clear();
        }

        // Handling 'env' command
        else if(strcmp(cmd[0],"env") == 0)
        {
            if(cnt == 1)
            {
                envIdx = 0;
                while (envp[envIdx])
                {
                    printf("%s\n", envp[envIdx++]);
                }
            }
            else
            {
                printf("%s: Command not found\n",buffer);
            }
        }

        // Handling 'cd' command
        else if(strcmp(cmd[0],"cd") == 0)
        {
            if(cnt == 1)
            {
                changeDir(homeDir);
            }
            else
            {
                changeDir(cmd[1]);
            }
        }

        // Handling 'pwd' command
        else if(strcmp(cmd[0],"pwd") == 0)
        {
            pwd();
        }

        // Handling 'mkdir' command
        else if(strcmp(cmd[0],"mkdir") == 0)
        {
            if(cnt == 1)
            {
                printf("mkdir: missing operand\n");
            }
            else
            {
                for(j=1; j<cnt; j++)
                    makeDir(cmd[j]);
            }
        }

        // Handling 'ls' and 'ls -l' command
        else if(strcmp(cmd[0],"ls") == 0)
        {
            if(cnt == 1)
            {
                ls(currDir);
            }
            else
            {
                if(strcmp(cmd[1],"-l")==0)
                {
                    lsl(currDir);
                }
            }
        }

        // Handling 'rmdir' command
        else if(strcmp(cmd[0],"rmdir") == 0)
        {
            if(cnt == 1)
            {
                printf("rmdir: missing operand\n");
            }
            else
            {
                for(j=1; j<cnt; j++)
                    removeDir(cmd[j]);
            }
        }

        // Handling 'history' command
        else if(strcmp(cmd[0],"history") == 0)
        {
            if(cnt == 1)
            {
                history();
            }
            else if(cnt == 2)
            {
                historyArg(atoi(cmd[1]));
            }
            else
            {
                printf("history: Too Many Arguments\n");
            }
        }

        // Handling 'exit' command
        else if(cnt ==1 && strcmp(cmd[0],"exit") == 0) return 0;

        // Handling background execution of commands
        else if(cmd[0][strlen(cmd[0])-1] == '&')
        {
            int pid = fork(),status;
            cmd[0][strlen(cmd[0])-1] = '\0';
            if(pid == 0)
            {
                if(execvp(cmd[0], &cmd[0]) == -1)printf("%s : Command Not Found\n",cmd[0]);
            }
        }

        // Handling background execution of commands
        else if(strcmp(cmd[cnt-1],"&") == 0)
        {
            int pid = fork(),status;
            cmd[0][strlen(cmd[0])] = '\0';
            if(pid == 0)
            {
                if(execvp(cmd[0], &cmd[0]) == -1)printf("%s : Command Not Found\n",cmd[0]);
            }
        }

        //Handling normal execution of commands
        else
        {
            int pid = fork(),status;
            if(pid == 0)
            {
                if(execvp(cmd[0], &cmd[0]) == -1)printf("%s : Command Not Found\n",cmd[0]);
            }
            else
            {
                waitpid(pid,&status,0);
            }
        }

    }

}
